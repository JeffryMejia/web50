from django.shortcuts import render
from django.http import HttpResponse
from .models import Persona

def index(request):
    p = Persona.objects.all()
    context = {
        "persona": p,
    }
    return render(request,'index.html',context)




